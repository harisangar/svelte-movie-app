<script context="module">
export async function load({fetch}){
    const res= await fetch(`
https://api.themoviedb.org/3/movie/popular?api_key=dc75c44703b0161b95bf78d86e108010&language=en-US&page=1`);
const data =await res.json();
if(res.ok){
    return{
        props:{
            popular:data.results
        }
    };
}
}
</script>
<script>
    import Popularmovies from "../components/Popularmovies.svelte";
    import Searchmovie from "../components/Searchmovie.svelte";
    export let popular;
    
</script>

<section>
    <Searchmovie />
    <Popularmovies {popular}/>
</section>