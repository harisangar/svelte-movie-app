<script context="module">
    export async function load({fetch,params}){
        const res= await fetch(`
https://api.themoviedb.org/3/movie/${params.id}?api_key=dc75c44703b0161b95bf78d86e108010&language=en-US`
    );
    const moviedetails =await res.json();
    if(res.ok){
        return{
            props:{
               moviedetails
            }
        };
    }
    }
    </script>
    <script>
        export let moviedetails;
    </script>

    <div class="movie-details">
        <div class="img-container">
            <img src={'https://image.tmdb.org/t/p/original'+ moviedetails.backdrop_path} alt={moviedetails.title} />

        </div>
        <div class="txt-container">
            <h1>{moviedetails.title}</h1>
            <p class="overview"> {moviedetails.overview}</p>
            <p>
                <span>Release date:</span>{moviedetails.release_date}<br/>
                <span>Budget:</span>{moviedetails.budget}<br/>
                <span>Rating:</span>{moviedetails.vote_average}<br/>
                <span>Runtime:</span>{moviedetails.runtime} mins <br/>
                
            </p>
        </div>
    </div>
    <style>
h1{
    padding: 1rem 0rem 2rem;
}
p{
    padding: 1rem 0rem ;
}
.img-container{
    width: 100%;
}
img{
    width: 100%;
    border-radius: 1rem;
}
.movie-details{
    margin: 2rem 20%;
}
span{
    font-weight: bold;
}


    </style>
