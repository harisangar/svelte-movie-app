<script>
    import global from '../global.css';
    import Nav from '../components/Nav.svelte';
</script>

<Nav />
<slot />